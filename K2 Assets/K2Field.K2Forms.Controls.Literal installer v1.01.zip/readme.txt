

1. run 'K2Field.K2Forms.Controls.Literal Installer.exe' on your K2 server
2. Copy 'K2Field.K2Forms.Controls.Literal.dll' into  

C:\Program Files (x86)\K2 blackpearl\K2 SmartForms Runtime\bin
and
C:\Program Files (x86)\K2 blackpearl\K2 SmartForms Designer\bin

3. Do an IISRESET 
4. Start K2forms and enjoy this control :)